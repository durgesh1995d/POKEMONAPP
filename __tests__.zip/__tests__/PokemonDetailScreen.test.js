// import React from 'react';
// import { render } from '@testing-library/react-native';
// import { Provider } from 'react-redux';
// import { store } from '../src/store';
// import PokemonDetailScreen from '../src/screens/PokemonDetailScreen';

 
// test('renders PokemonDetailScreen correctly', () => {
//  const route = { params: { name: 'pikachu' } };
//  const { getByText } = render(
//  <Provider store={store}>
//  <PokemonDetailScreen route={route} />
//  </Provider>
//  );
//  expect(getByText('Loading...')).toBeTruthy();
// });

// __tests__/PokemonDetailScreen.test.js
// import React from 'react';
// import { render } from '@testing-library/react-native';
// import { Provider } from 'react-redux';
 
// import PokemonDetailScreen from '../src/screens/PokemonDetailScreen';
// import { useGetPokemonByNameQuery } from '@reduxjs/toolkit/query/react';

// // Mock the API hook
// jest.mock('@reduxjs/toolkit/query/react');

// jest.mock('react-redux', () => {
//   const real = jest.requireActual('redux-persist');

//   return {
//     connect: (mapStateToProps, mapDispatchToProps) => (ReactComponent) => ({
//       mapStateToProps,
//       mapDispatchToProps,
//       ReactComponent,
//     }),
//     Provider: ({ children }) => children,
//          ...real,
//         persistReducer: jest.fn().mockImplementation((config, reducers) => reducers),
    

//   };
// });

 
// describe('PokemonDetailScreen', () => {
//   beforeEach(() => {
//     // Clear all instances and calls to constructor and all methods:
//     jest.clearAllMocks();
//   });

//   it('renders loading state correctly', () => {
//     // Mock the hook to return loading state
//     useGetPokemonByNameQuery.mockReturnValue({
//       data: null,
//       error: null,
//       isLoading: true,
//     });

//     const route = { params: { name: 'pikachu' } };
//     const { getByText } = render(
//       <Provider store={store}>
//         <PokemonDetailScreen route={route} />
//       </Provider>
//     );

//     expect(getByText('Loading...')).toBeTruthy();
//   });

//   it('renders error state correctly', () => {
//     // Mock the hook to return error state
//     useGetPokemonByNameQuery.mockReturnValue({
//       data: null,
//       error: { message: 'Something went wrong' },
//       isLoading: false,
//     });

//     const route = { params: { name: 'pikachu' } };
//     const { getByText } = render(
//       <Provider store={store}>
//         <PokemonDetailScreen route={route} />
//       </Provider>
//     );

//     expect(getByText('Error: Something went wrong')).toBeTruthy();
//   });

//   it('renders pokemon data correctly', () => {
//     // Mock the hook to return data
//     useGetPokemonByNameQuery.mockReturnValue({
//       data: { name: 'pikachu', height: 4 },
//       error: null,
//       isLoading: false,
//     });

//     const route = { params: { name: 'pikachu' } };
//     const { getByText } = render(
//       <Provider store={store}>
//         <PokemonDetailScreen route={route} />
//       </Provider>
//     );

//     expect(getByText('Pokemon Name: pikachu')).toBeTruthy();
//     expect(getByText('Pokemon Height: 4')).toBeTruthy();
//   });
// });

import React from 'react';
import { render } from '@testing-library/react-native';
import PokemonDetailScreen from '../src/screens/PokemonDetailScreen';
import PokemonDetail from '../src/component/PokemonDetail';

// Mock the PokemonDetail component
jest.mock('../src/component/PokemonDetail', () => 'PokemonDetail');

describe('PokemonDetailScreen', () => {
  it('renders PokemonDetailScreen correctly', () => {
    const route = { params: { name: 'pikachu' } }; // Mock route prop

    const { getByTestId,toJSON } = render(<PokemonDetailScreen route={route} />);

    expect(getByTestId('PokemonDetail')).toBeTruthy();
 expect(toJSON()).toMatchSnapshot();
  });
});
